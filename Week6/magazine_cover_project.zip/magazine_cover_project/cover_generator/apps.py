from django.apps import AppConfig


class CoverGeneratorConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'cover_generator'
