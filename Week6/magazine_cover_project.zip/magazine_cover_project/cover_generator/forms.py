from django import forms

class CoverForm(forms.Form):
    title = forms.CharField(label='Magazine Title', max_length=100)
    subtitle = forms.CharField(label='Subtitle', max_length=200, required=False)
    image = forms.ChoiceField(
        label='Background Image',
        choices=[
            ('IMG1.jpeg', 'Image 1'),
            ('IMG2.jpeg', 'Image 2'),
            ('IMG3.jpeg', 'Image 3'),
        ]
    )
    background_color = forms.CharField(
        label='Background Color',
        widget=forms.TextInput(attrs={'type': 'color'}),
        initial='#FFFFFF'  # Default white
    )
    font_size = forms.IntegerField(label='Font Size', initial=32)
    font_color = forms.CharField(
        label='Font Color',
        widget=forms.TextInput(attrs={'type': 'color'}),
        initial='#000000'  # Default black
    )
    font_family = forms.ChoiceField(
        label='Font Family',
        choices=[
            ('Arial, sans-serif', 'Arial'),
            ('Helvetica, sans-serif', 'Helvetica'),
            ('Times New Roman, serif', 'Times New Roman'),
            ('Georgia, serif', 'Georgia'),
            ('Courier New, monospace', 'Courier New'),
        ]
    )
