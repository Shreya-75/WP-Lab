from django.shortcuts import render
from .forms import CoverForm

def generate_cover(request):
    if request.method == 'POST':
        form = CoverForm(request.POST)
        if form.is_valid():
            title = form.cleaned_data['title']
            subtitle = form.cleaned_data['subtitle']
            image = form.cleaned_data['image']
            background_color = form.cleaned_data['background_color']
            font_size = form.cleaned_data['font_size']
            font_color = form.cleaned_data['font_color']
            font_family = form.cleaned_data['font_family']

            context = {
                'title': title,
                'subtitle': subtitle,
                'image': image,
                'background_color': background_color,
                'font_size': font_size,
                'font_color': font_color,
                'font_family': font_family,
            }

            return render(request, 'cover_generator/cover_preview.html', context)
    else:
        form = CoverForm()
    return render(request, 'cover_generator/cover_form.html', {'form': form})
