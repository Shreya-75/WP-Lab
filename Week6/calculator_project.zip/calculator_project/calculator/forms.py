from django import forms

class CalculatorForm(forms.Form):
    num1 = forms.IntegerField(label='Number 1')
    num2 = forms.IntegerField(label='Number 2')
    operation = forms.ChoiceField(label='Operation', choices=[
        ('add', 'Addition'),
        ('subtract', 'Subtraction'),
        ('multiply', 'Multiplication'),
        ('divide', 'Division'),
    ])
